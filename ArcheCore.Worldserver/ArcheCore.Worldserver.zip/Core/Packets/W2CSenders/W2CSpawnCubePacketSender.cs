﻿using System.Collections.Generic;
using ArcheCore.Library.Net.Worldserver;
using ArcheCore.WorldServer.Managers;
using LiteNetLib;
using Shared;
using Shared.Components;

namespace ArcheCore.WorldServer.Networking.W2C
{
    public static class W2CSpawnCubePacketSender
    {
        public static void Send(
            ReplicationManager replication,
            NetPeer peer,
            int cubeId,
            float x, float y, float z)
        {
            replication.Send(
                Opcodes.SpawnCube,
                new W2CSpawnCubePacket { CubeId = cubeId, x = x, y = y, z = z },
                peer);
        }

        public static void Broadcast(
            ReplicationManager replication,
            IEnumerable<NetPeer> peers,
            int cubeId,
            float x, float y, float z)
        {
            replication.Broadcast(
                Opcodes.SpawnCube,
                new W2CSpawnCubePacket { CubeId = cubeId, x = x, y = y, z = z },
                peers);
        }
    }
}