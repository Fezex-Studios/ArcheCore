﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using ArcheCore.Worldserver.Utils.Config;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace Shared.AuthService
{
    public class AuthService
    {
        private static readonly HttpClient Http = new HttpClient();
        private readonly ILogger<AuthService> _logger;

        public AuthService(ILogger<AuthService> logger)
        {
            _logger = logger;
        }

        [Serializable]
        private class ValidateResponse
        {
            [JsonProperty("Valid")]
            public bool Valid;

            [JsonProperty("AccountId")]
            public int AccountId;
        }

        public async Task<int> ValidateToken(string token)
        {
            try
            {
                string url  = $"{ConfigService.Config.AuthServerUrl}/validate-session";
                string body = JsonConvert.SerializeObject(new { Token = token });

                var request = new HttpRequestMessage(HttpMethod.Post, url)
                {
                    Content = new StringContent(body, Encoding.UTF8, "application/json")
                };

                request.Headers.Add("x-internal-secret", ConfigService.Config.InternalSecret);

                HttpResponseMessage response = await Http.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError("Validate request failed with status {StatusCode}", response.StatusCode);
                    return -1;
                }

                string json = await response.Content.ReadAsStringAsync();
                ValidateResponse result = JsonConvert.DeserializeObject<ValidateResponse>(json);

                if (result == null)
                {
                    _logger.LogError("Empty or malformed response from auth server");
                    return -1;
                }

                return result.Valid ? result.AccountId : -1;
            }
            catch (Exception e)
            {
                _logger.LogError("Validation request failed: {Message}", e.Message);
                return -1;
            }
        }
    }
}