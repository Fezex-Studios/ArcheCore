﻿using MessagePack;

namespace ArcheCore.Network.Shared.Packets.PersistenceServer.P2W
{
    [MessagePackObject(true)]
    public class P2WCharacterLoadResponse
    {
        public bool   Found;
        public int    AccountId;
        public long   CharacterId;
        public string Name;
        public int    Level;
        public float  X;
        public float  Y;
        public float  Z;
    }
}