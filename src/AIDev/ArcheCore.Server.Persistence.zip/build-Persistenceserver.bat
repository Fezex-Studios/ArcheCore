bun build src/index.ts --compile --outfile ./bin/ArcheCore.Persistenceserver
pause