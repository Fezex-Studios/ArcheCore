export enum ProtocolPersistence
{
    W2PConnectRequest = 1,

    CharacterSave = 2,

    CharacterLoad = 3,
    P2WConnectResponse=4,
    HelloWorld =5
}