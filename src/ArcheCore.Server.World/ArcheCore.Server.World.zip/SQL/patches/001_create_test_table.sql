﻿CREATE TABLE IF NOT EXISTS "Test" (
                                       "Id"      INTEGER NOT NULL,
                                       "Name"    TEXT    NOT NULL,
                                       "MaxStack" INTEGER NOT NULL,
                                       CONSTRAINT "PK_Items" PRIMARY KEY("Id" AUTOINCREMENT)
    );