﻿using System.Collections.Generic;
using System.Numerics;
using ArcheCore.Server.World.GameData.Npcs;
using ArcheCore.Server.World.GameData.World;
using ArcheCore.Server.World.GameData.World.Spawners;
using ArcheCore.Server.World.Utils.Database.SQLite;
using LiteNetLib;
using Microsoft.EntityFrameworkCore;
using NLog;

namespace ArcheCore.Server.World.Managers;

public class SpawnManager
{
    private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

    private readonly ReplicationManager _replication;
    private readonly IDbContextFactory<WorldDataDbContext> _dbFactory;
    private readonly WorldObjectRegistry _registry;
    private readonly CubeSpawner _cubeSpawner;
    private readonly NpcSpawner _npcSpawner;

    private int _nextId = 1;

    public SpawnManager(
        ReplicationManager replication,
        IDbContextFactory<WorldDataDbContext> dbFactory)
    {
        _replication = replication;
        _dbFactory   = dbFactory;
        _registry    = new WorldObjectRegistry();

        _cubeSpawner = new CubeSpawner(replication);
        _npcSpawner  = new NpcSpawner(replication);

        _registry.Register(_cubeSpawner);
    }

    public void SpawnInitialObjects()
    {
        using var db = _dbFactory.CreateDbContext();

        int spawned = 0;
        int skipped = 0;

        // World objects (cubes, props etc)
        var worldObjects = db.WorldObjects.ToList();
        foreach (var obj in worldObjects)
        {
            int id = _nextId++;
            bool success = _registry.Spawn(id, obj.Type, new Vector3(obj.X, obj.Y, obj.Z));
            if (success) spawned++;
            else skipped++;
        }

        Logger.Info($"Spawned {spawned} world objects from database. ({skipped} skipped — no spawner registered)");

        // NPCs — join spawner table + template
        var spawners  = db.NpcSpawners.ToList();
        var templates = db.NpcTemplates.ToDictionary(t => t.Id);

        foreach (var spawner in spawners)
        {
            if (!templates.TryGetValue(spawner.TemplateId, out var template))
            {
                Logger.Warn($"NpcSpawner {spawner.Id} references unknown TemplateId {spawner.TemplateId}");
                continue;
            }

            for (int i = 0; i < spawner.Count; i++)
            {
                int networkId = _nextId++;
                _npcSpawner.SpawnFromTemplate(
                    networkId,
                    template,
                    new Vector3(spawner.X, spawner.Y, spawner.Z));

                Logger.Info($"Spawned NPC '{template.Name}' (NetworkId={networkId}) at ({spawner.X}, {spawner.Y}, {spawner.Z})");
            }
        }
    }

    public void SendWorldToPeer(NetPeer peer)
    {
        _cubeSpawner.SendToPeer(peer);
        _npcSpawner.SendToPeer(peer);
    }
}