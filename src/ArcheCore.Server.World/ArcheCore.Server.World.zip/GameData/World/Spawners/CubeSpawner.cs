﻿using System.Numerics;
using ArcheCore.Library.Net.Worldserver;
using ArcheCore.Network.Shared.Packets.W2C;
using ArcheCore.Server.World.Managers;
using LiteNetLib;

namespace ArcheCore.Server.World.GameData.World.Spawners;

public class CubeSpawner(ReplicationManager replication): IWorldObjectSpawner
{
    public string Type => "Cube";
    private readonly Dictionary<int, Vector3> _live = new();

    public void OnSpawn(int id, Vector3 position)
    {
        _live[id] = position;
    }

    public void SendToPeer(NetPeer peer)
    {
        foreach (var (id, pos)in _live)
        {
            replication.Send(Opcodes.SpawnWorldObject,
                new W2CSpawnWorldObjectPacket
                {
                    Id   = id,
                    Type = Type,
                    X    = pos.X,
                    Y    = pos.Y,
                    Z    = pos.Z
                },peer);
        }
    }
    public void Broadcast(int id, Vector3 position, IEnumerable<NetPeer> peers)
    {
        _live[id] = position;
        replication.Broadcast(Opcodes.SpawnWorldObject,
            new W2CSpawnWorldObjectPacket
            {
                Id   = id,
                Type = Type,
                X    = position.X,
                Y    = position.Y,
                Z    = position.Z
            }, peers);
    }
}