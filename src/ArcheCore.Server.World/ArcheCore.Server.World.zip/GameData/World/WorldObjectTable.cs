﻿namespace ArcheCore.Server.World.GameData.World;

public class WorldObjectTable
{
    public int Id { get; set; }
    public string Type { get; set; } = string.Empty;
    public float X { get; set; }
    public float Y { get; set; }
    public float Z { get; set; }
}