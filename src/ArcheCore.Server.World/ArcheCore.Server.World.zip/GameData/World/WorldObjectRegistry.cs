﻿using System.Numerics;
using NLog;

namespace ArcheCore.Server.World.GameData.World;

public class WorldObjectRegistry
{
    private readonly Logger Logger = LogManager.GetCurrentClassLogger();
    private readonly Dictionary<string, IWorldObjectSpawner> _spawners = new();

    public void Register(IWorldObjectSpawner spawner)
    {
        _spawners[spawner.Type] = spawner;
        Logger.Debug($"[WorldObjectRegistry] Registered spawner for type '{spawner.Type}'");
    }

    public bool Spawn(int id, string type, Vector3 position)
    {
        if (!_spawners.TryGetValue(type, out var spawner))
        {
            Logger.Warn($"[WorldObjectRegistry] No spawner registered for type '{type}'");
            return false;
        }
        spawner.OnSpawn(id, position);
        return true;
    }
}