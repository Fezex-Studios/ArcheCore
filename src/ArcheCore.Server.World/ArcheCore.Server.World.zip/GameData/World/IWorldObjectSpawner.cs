﻿using System.Numerics;

namespace ArcheCore.Server.World.GameData.World;

public interface IWorldObjectSpawner
{
    string Type { get; }
    void OnSpawn(int id, Vector3 position);

}